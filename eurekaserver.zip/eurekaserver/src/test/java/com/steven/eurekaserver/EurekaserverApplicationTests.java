package com.steven.eurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
